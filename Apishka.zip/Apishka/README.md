# collegeFlask
Задание 3 по учебной практике на создание api с помощью фреймворка Flask
<br>
Возможные запросы:<br>
<pre>
/
/?amount=2 (сколько показать)
/?column=названиеCтолбца (author или content)
</pre>
Запустить приложение (windows):
```
install.bat
```
Запустить приложение (unix):
```
source install_unix.bat
```
...в папке с файлами.
